const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { PDFDocument } = require('pdf-lib');  // pdf-lib for reading PDF files

let mainWindow;
let isConverting = false;
let pythonProcess=null
function createWindow() {
    mainWindow = new BrowserWindow({
        width: 800,
        height: 600,
        webPreferences: {
            nodeIntegration: true,
            contextIsolation: false
        }
    });
    mainWindow.loadFile('index.html');
}

app.on('ready', createWindow);

app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
        app.quit();
    }
});

// Handle file selection dialog
ipcMain.handle('open-file-dialog', async () => {
    const result = await dialog.showOpenDialog({
        properties: ['openFile'],
        filters: [{ name: 'PDF Files', extensions: ['pdf'] }]
    });
    return result.filePaths[0] || null;
});

// Handle the file conversion request
ipcMain.on('convert-to-audio', (event, filePath, startPage, endPage) => {
    if (isConverting) {
        event.reply('conversion-status', 'Another conversion is already in progress.');
        return;
    }

    isConverting = true;
    const pythonScriptPath = path.join(__dirname, 'convert.py');
    const tempDir = path.join(os.tmpdir(), 'pdf-to-audio');
    const outputFilePath = path.join(tempDir, 'converted_audio.mp3');

    if (!fs.existsSync(tempDir)) {
        fs.mkdirSync(tempDir);
    }

    event.reply('conversion-status', 'Converting...');

    const pythonProcess = spawn('python', [pythonScriptPath, filePath, startPage, endPage, outputFilePath]);

    pythonProcess.stdout.on('data', (data) => {
        const output = data.toString();
        console.log(`Python stdout: ${output}`);

        // Parse progress updates and send to renderer
        const progressMatch = output.match(/PROGRESS:(\d+(\.\d+)?)/);
        if (progressMatch) {
            const progress = parseFloat(progressMatch[1]);
            event.reply('conversion-progress', progress);
        }
    });

    pythonProcess.stderr.on('data', (data) => {
        console.error(`Python stderr: ${data}`);
        event.reply('conversion-status', `Error: ${data.toString()}`);
    });

    pythonProcess.on('close', (code) => {
        isConverting = false;
        if (code === 0) {
            event.reply('conversion-status', 'Conversion complete!');
            event.reply('audio-file-path', outputFilePath);
        } else {
            event.reply('conversion-status', 'Conversion failed.');
        }
    });
});

// Handle the request for getting the total number of pages in the PDF
ipcMain.handle('get-pdf-pages', async (event, filePath) => {
    try {
        const pdfBytes = fs.readFileSync(filePath);  // Read the file as a buffer
        const pdfDoc = await PDFDocument.load(pdfBytes);  // Load the PDF file
        return pdfDoc.getPages().length;  // Return the total number of pages
    } catch (error) {
        console.error('Error reading PDF file:', error);
        return 0;  // Return 0 pages if there's an error
    }
});

// Clean up temporary files and directory on app quit
app.on('quit', () => {
    if (pythonProcess && !pythonProcess.killed) {
        pythonProcess.kill('SIGTERM'); // Terminate the Python process
    }

    const tempDir = path.join(os.tmpdir(), 'pdf-to-audio');
    const tempFilePath = path.join(tempDir, 'converted_audio.mp3');

    // Wrap the deletion in a try-catch block
    try {
        // Check if the file exists
        if (fs.existsSync(tempFilePath)) {
            // Attempt to delete the file (optional, if you still want to clean up)
            fs.unlinkSync(tempFilePath); 
            console.log(`Temporary file deleted: ${tempFilePath}`);
        }
    } catch (error) {
        if (error.code === 'EBUSY' || error.code === 'EACCES') {
            console.warn(`File is busy or locked. Skipping deletion: ${tempFilePath}`);
        } else {
            console.error(`Unexpected error during file cleanup: ${error.message}`);
        }
    }

    // (Optional) Clean up the temporary directory, if necessary
    try {
        if (fs.existsSync(tempDir)) {
            fs.rmSync(tempDir, { recursive: true, force: true });
            console.log(`Temporary directory deleted: ${tempDir}`);
        }
    } catch (error) {
        console.error(`Error during directory cleanup: ${error.message}`);
    }
});
