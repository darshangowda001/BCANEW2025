const { ipcRenderer } = require('electron');
const path = require('path');

let selectedFilePath = null; // Variable to store the selected file path

// Handle the "Select File" button click
document.getElementById('select-file-btn').addEventListener('click', () => {
    ipcRenderer.invoke('open-file-dialog')
        .then((filePath) => {
            if (filePath) {
                selectedFilePath = filePath;
                const fileName = path.basename(filePath);  // Extract the file name without path
                document.getElementById('selected-file-name').innerText = `Selected file: ${fileName}`;
                // Send the file path to the main process to get the total number of pages
                ipcRenderer.invoke('get-pdf-pages', filePath)
                    .then((totalPages) => {
                        // Display total number of pages
                        document.getElementById('total-pages').textContent = `Total Pages: ${totalPages}`;
                        document.getElementById('select-statement').textContent=`Enter the range of pages you want to convert`;
                    })
                    .catch((error) => {
                        console.error('Error getting total pages:', error);
                    });
            }
        })
        .catch((error) => {
            console.error('Error selecting file:', error);
        });
});

// Handle the "Convert" button click
document.getElementById('convertBtn').addEventListener('click', () => {
    if (!selectedFilePath) {
        document.getElementById('status').innerText = 'Please select a file first.';
        return; // Stop further processing if no file is selected
    }

    const startPage = document.getElementById('startPage').value || 1;
    const endPage = document.getElementById('endPage').value || '';


    // Show the progress bar
    document.getElementById('progress-bar-container').style.display = 'block';

    // Send the conversion request to the main process with the file path and page range
    ipcRenderer.send('convert-to-audio', selectedFilePath, startPage, endPage);
});

// Listen for conversion status updates
ipcRenderer.on('conversion-status', (event, message) => {
    const statusDiv = document.getElementById('status');
    statusDiv.innerText = message;
});

// Listen for the path to the generated audio file
ipcRenderer.on('audio-file-path', (event, audioFilePath) => {
    const downloadLink = document.getElementById('download-link');
    const audioPlayer = document.getElementById('audioPlayer');

    // Set up the download link
    downloadLink.href = audioFilePath;
    downloadLink.download = 'converted_audio.mp3';
    downloadLink.style.display = 'inline';

    // Set up the audio player
    audioPlayer.src = audioFilePath;  // Set the source of the audio player
    audioPlayer.style.display = 'block';  // Make the audio player visible

        // Hide the progress bar after conversion is complete
       // document.getElementById('progress-bar-container').style.display = 'none';
});
// Listen for progress updates
ipcRenderer.on('conversion-progress', (event, progress) => {
    console.log(`Progress update received: ${progress}%`);  // Debug log
    const progressBar = document.getElementById('progress-bar');
    const progressPercentage = document.getElementById('progress-percentage');

    if (progressBar) {
        progressBar.value = progress;  // Update the progress bar value
    }
    if (progressPercentage) {
        progressPercentage.textContent = `${progress.toFixed(1)}%`;  // Set text to display percentage
    }
    
});
