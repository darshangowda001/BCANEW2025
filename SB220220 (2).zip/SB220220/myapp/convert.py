import sys
import os
import signal
import PyPDF2
from gtts import gTTS
from io import BytesIO
from filelock import FileLock
import atexit



def handle_termination_signal(signum, frame):
    print("Termination signal received. Exiting...")
    sys.exit(0)

# Register the signal handler
signal.signal(signal.SIGTERM, handle_termination_signal)
signal.signal(signal.SIGINT, handle_termination_signal)  # Handle Ctrl+C

# Get file path from command line argument
book = sys.argv[1]
start_page = int(sys.argv[2])  # Start page from Electron
end_page = int(sys.argv[3]) if sys.argv[3] != '' else None  # End page from Electron, if provided

def read_pdf(file_path, start_page=1, end_page=None):
    try:
        pdf_reader = PyPDF2.PdfReader(file_path)
        total_pages = len(pdf_reader.pages)

        # Validate and adjust page range
        if start_page < 1 or start_page > total_pages:
            print(f"Invalid start page. Valid range: 1-{total_pages}")
            return ""
        if end_page is None or end_page > total_pages:
            end_page = total_pages
        if start_page > end_page:
            print("Start page cannot be greater than end page.")
            return ""

        # Extract text for the specified range
        text = ""
        for num in range(start_page - 1, end_page):
            try:
                page = pdf_reader.pages[num]
                text += page.extract_text() + "\n"
            except Exception as e:
                print(f"Error reading page {num + 1}: {e}")
                continue  # Skip problematic pages

        return text
    except PyPDF2.errors.PdfReadError as e:
        print(f"PDF reading error: {e}")
        return ""
    except Exception as e:
        print(f"Unexpected error reading PDF: {e}")
        return ""



def save_as_mp3(text, output_file):
    try:
        # Validate input text
        if not text.strip():
            raise ValueError("Input text is empty. Cannot convert to audio.")

        # Split text into chunks (split by periods as a basic example)
        chunks = text.split(".")
        total_chunks = len(chunks)
        if total_chunks == 0:
            raise ValueError("No valid chunks found in the input text.")

        # Ensure the directory for the output file exists
        output_dir = os.path.dirname(output_file)
        if output_dir and not os.path.exists(output_dir):
            os.makedirs(output_dir)

        # Open a file for saving the combined audio
        audio_file = None
        try:
            audio_file = open(output_file, "wb")
            for idx, chunk in enumerate(chunks):
                chunk = chunk.strip()
                if chunk:  # Skip empty chunks
                    try:
                        # Convert text chunk to speech
                        tts = gTTS(chunk)
                        temp_file = "temp_audio.mp3"  # Use a single temp file
                        with FileLock(f"{temp_file}.lock"):  # Lock the file during processing
                            tts.save(temp_file)

                            # Append the temporary file's contents to the final file
                            with open(temp_file, "rb") as temp_audio:
                                audio_file.write(temp_audio.read())
                            
                            # Clean up the temporary file
                            os.remove(temp_file)

                    except Exception as chunk_error:
                        print(f"Error processing chunk {idx + 1}: {chunk_error}", flush=True)
                        continue

                # Emit progress update
                progress = ((idx + 1) / total_chunks) * 100
                print(f"PROGRESS:{progress:.2f}", flush=True)
        finally:
            if audio_file:
                audio_file.close()
        # Emit final progress update to ensure 100% completion
        print("PROGRESS:100.00", flush=True)
        print("Audio saved successfully.")
        return output_file

    except Exception as e:
        print(f"Error converting text to audio: {e}")
        return None


# Ensure output file path is valid
def is_valid_file_path(file_path):
    return os.path.isdir(os.path.dirname(file_path))

# Read the file and get text within the specified range
text = read_pdf(book, start_page=start_page, end_page=end_page)

if text.strip():
    print("Reading the document...")

    # Define the path where the MP3 file should be saved
    output_file = sys.argv[4]  # Get the output file path from command-line argument
    
    # Validate the output file path
    if not is_valid_file_path(output_file):
        print("Invalid output file path. Please check the directory.")
    else:
        # Generate the MP3 file and save it
        saved_audio_file = save_as_mp3(text, output_file)
        if saved_audio_file:
            print(f"Audio saved as {saved_audio_file}")
        else:
            print("Error generating audio.")
else:
    print("The document is empty or could not be read.")
